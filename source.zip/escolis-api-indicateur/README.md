# escolis-api-indicateur
- run the app using
```
docker-compose --env-file docker.env up --build -d
```
